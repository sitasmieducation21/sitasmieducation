import React from "react";

export default function Home() {
  return (
    <main className="p-6 space-y-8 bg-white text-gray-800">
      <header className="text-center">
        <img src="/Sitasmi Educational Consultancy Logo.png" alt="Sitasmi Logo" className="mx-auto w-32" />
        <h1 className="text-4xl font-bold mt-4 text-green-700">Sitasmi Educational Consultancy and Training Center</h1>
        <p className="mt-2 text-lg">Guiding Your Future to Japan</p>
      </header>

      <section id="about" className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">About Us</h2>
        <p>
          Sitasmi Educational Consultancy and Training Center offers language training and visa support for students
          aspiring to study in Japan. We specialize in preparing candidates who have passed the SSW (Specified Skilled Worker)
          exam and aim to work in fields such as nursing care, hospitality, agriculture, and driving.
        </p>
      </section>

      <section id="services" className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">Our Services</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>Japanese Language Training</li>
          <li>Visa Application Support</li>
          <li>Job Placement Assistance in Japan (Nursing, Caregiving, Hotel, Agriculture, Driving)</li>
        </ul>
      </section>

      <section id="audience" className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">Who We Help</h2>
        <p>
          Our services are tailored for students and skilled workers from Nepal aiming to pursue education or career opportunities in Japan.
        </p>
      </section>

      <section id="testimonials" className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">Testimonials</h2>
        <blockquote className="italic">"Sitasmi helped me secure a job in Japan's nursing sector. Their support is truly life-changing!"</blockquote>
        <p className="text-right">- Ramesh T.</p>
      </section>

      <section id="contact" className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">Contact Us</h2>
        <p>📍 Bharatpur-25, Chitwan</p>
        <p>📞 9841507600</p>
        <p>📧 sitasmieducation21@gmail.com</p>
        <p>📸 Instagram: @sitasmieducation21</p>
        <p>📘 Facebook: <a href="https://www.facebook.com/share/1ED5i63RuN/?mibextid=wwXIfr" className="text-blue-600">facebook.com/sitasmieducation21</a></p>
      </section>

      <section className="space-y-4">
        <h2 className="text-2xl font-semibold text-green-700">Send Us a Message</h2>
        <form className="space-y-4">
          <input type="text" placeholder="Your Name" className="w-full p-2 border rounded" required />
          <input type="email" placeholder="Your Email" className="w-full p-2 border rounded" required />
          <textarea placeholder="Your Message" className="w-full p-2 border rounded h-32" required></textarea>
          <button type="submit" className="bg-green-700 text-white px-4 py-2 rounded">Send Message</button>
        </form>
      </section>
    </main>
  );
}